# Student Record System (C)

This is a simple Student Record Management System written in C.

## Features
- Add student details
- Display all students
- Search student by ID

## How to Run

### Compile:
gcc main.c -o student

### Run:
./student

## File Storage
Data is stored in `students.txt`.

## Author
Your Name
